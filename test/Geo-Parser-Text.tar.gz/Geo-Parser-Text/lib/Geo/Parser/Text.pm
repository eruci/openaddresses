package Geo::Parser::Text;

use 5.006;
use strict;
use warnings;

use XML::Simple;
use LWP::UserAgent;
use HTTP::Request;
use URI;
use Data::Dumper;


use constant DEBUG    => 0;
use constant GEO_HOST => q{http://geocode.xyz};

sub new {
    my $class = shift;

    my $self = {
        geo_host        => shift
    };

    bless ($self, $class);
    return $self;
}

sub geodata {
  my $self = shift;
  $self->{geodata} = $_[0] if $_[0];
  return $self->{geodata};
}

sub geoit {
  my $self = shift;
  $self->{geoit} = $_[0] if $_[0];
  return $self->{geoit};
}

sub scantext {
  my $self = shift;
  $self->{scantext} = $_[0] if $_[0];
  return $self->{scantext};
}
sub geo_result {
  my $self = shift;
  $self->{geo_result} = $_[0] if $_[0];
  return $self->{geo_result};
}

sub geocode {
  my $self    = shift;

  my %form_values;
  foreach my $param (qw(scantext geoit)) {
    $form_values{$param} = $self->$param;
  }
  $form_values{geoit} = 'XML' unless $form_values{geoit};

warn Data::Dumper->Dump([\%form_values],['Form Values']) if DEBUG;

  $self->process_request(%form_values);

    my $geodata    = $self->geodata;
	my @a = split(/<geodata/,$geodata);
	my $geod = pop @a;
	$geod = '<geodata>' . $geod;
	my $ref = XMLin($geod);
warn Data::Dumper->Dump([$ref],['Response']) if DEBUG;
$self->geo_result($ref);

  return $self->geo_result;
}

sub process_request {
  my $self        = shift;
  my %form_values = @_;
  $self->{geo_host} = GEO_HOST unless $self->{geo_host};

  my $uri = URI->new;
  $uri->query_form(%form_values);
  my $ua  = LWP::UserAgent->new;
  my $req = HTTP::Request->new(POST => $self->{geo_host});
  $req->content_type('application/x-www-form-urlencoded');
  $req->content($uri->query);

  my $res    = $ua->request($req);
  my $result = $res->as_string;

warn $result if DEBUG;

  my $geodata = $result;


  return $self->geodata($geodata);
}



=head1 NAME

Geo::Parser::Text - Perl extension for parsing and geocoding locations from free form text. (See Geocode.xyz for coverage details)

=head1 VERSION

Version 0.01

=cut

our $VERSION = '0.01';


=head1 SYNOPSIS

use Geo::Parser::Text;
  
# initialize with your host
my $g = Geo::Parser::Text->new([geo_host]);

# Scan text for locations...
$g->scantext($text);
  
if ($g->geocode) {
my $hashref  = $g->geodata;
}
                     
# Example...

use Geo::Parser::Text;

my $g = Geo::Parser::Text->new('http://geocode.xyz');
    
$g->scantext('The most important museums of Amsterdam are located on the Museumplein, located at the southwestern side of the Rijksmuseum.');
if ($g->geocode) {
        my $ref = $g->geocode;
        my @matches = @{$ref->{match}};
        my $number_of_matches = 0;
        foreach (@matches) {
                my $match = $_;
                $number_of_matches++;
                print "Match: $number_of_matches\n";
                foreach (keys %$match) {
                        print "\t" . $_ . " -> " . $match->{$_} . "\n";
                }
        }
}
                        
  
Output:
Match: 1
	longt -> 4.89546848846317
	location -> Amsterdam, NL
	confidence -> 0.7
	latt -> 52.35968449881906
Match: 2
	longt -> 4.8798549000
	location -> MUSEUMPLEIN, AMSTERDAM, NL
	confidence -> 0.4
	latt -> 52.3579099000

=head1 DESCRIPTION

This module provides a Perl frontend for the geocode.xyz API. It allows the programmer to extract locations containing street addresses, street intersections and city names along with their geocoded latitude,longitude from bodies of text such as microblogs or wikipedia entries. (It should work with any type of text, but dumping html text or paragraphs containing over 200 words, will slow down the response considerably. If you need faster parsing grab the geocode.xyz server image on the AWS, and run it on a faster server (it is currenly running on a micro instance and is shared as a free public API without any throttling or rate limiting in place.)
If you run your own instance, make sure to pass the instance ip address or domain name at invocation eg, Geo::Parser::Text->new($server).
For explanation on the API responses see http://geocode.xyz/?premium_api=1
 
=head2 METHODS

=head2 new ( host => 'geocode.xyz');

=item geocode()

Send the text to geocode.xyz and return the hash reference with the response.
You are required to set the scantext method before calling geocode().



 
=head1 EXPORT

None by default.



=head1 REQUIREMENTS

XML::Simple,
LWP::UserAgent,
HTTP::Request,
URI

=head1 AUTHOR

Ervin Ruci, C<< <eruci at geocoder.ca> >>

=head1 BUGS

Please report any bugs or feature requests to C<bug-geo-parser-text at rt.cpan.org>, or through
the web interface at L<http://rt.cpan.org/NoAuth/ReportBug.html?Queue=Geo-Parser-Text>.  I will be notified, and then you'll
automatically be notified of progress on your bug as I make changes.




=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc Geo::Parser::Text


You can also look for information at:

=over 4

=item * RT: CPAN's request tracker (report bugs here)

L<http://rt.cpan.org/NoAuth/Bugs.html?Dist=Geo-Parser-Text>

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/Geo-Parser-Text>

=item * CPAN Ratings

L<http://cpanratings.perl.org/d/Geo-Parser-Text>

=item * Search CPAN

L<http://search.cpan.org/dist/Geo-Parser-Text/>

=back


=head1 ACKNOWLEDGEMENTS


=head1 LICENSE AND COPYRIGHT

Copyright 2016 Ervin Ruci.

This program is free software; you can redistribute it and/or modify it
under the terms of the the Artistic License (2.0). You may obtain a
copy of the full license at:

L<http://www.perlfoundation.org/artistic_license_2_0>

Any use, modification, and distribution of the Standard or Modified
Versions is governed by this Artistic License. By using, modifying or
distributing the Package, you accept this license. Do not use, modify,
or distribute the Package, if you do not accept this license.

If your Modified Version has been derived from a Modified Version made
by someone other than you, you are nevertheless required to ensure that
your Modified Version complies with the requirements of this license.

This license does not grant you the right to use any trademark, service
mark, tradename, or logo of the Copyright Holder.

This license includes the non-exclusive, worldwide, free-of-charge
patent license to make, have made, use, offer to sell, sell, import and
otherwise transfer the Package with respect to any patent claims
licensable by the Copyright Holder that are necessarily infringed by the
Package. If you institute patent litigation (including a cross-claim or
counterclaim) against any party alleging that the Package constitutes
direct or contributory patent infringement, then this Artistic License
to you shall terminate on the date that such litigation is filed.

Disclaimer of Warranty: THE PACKAGE IS PROVIDED BY THE COPYRIGHT HOLDER
AND CONTRIBUTORS "AS IS' AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES.
THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED TO THE EXTENT PERMITTED BY
YOUR LOCAL LAW. UNLESS REQUIRED BY LAW, NO COPYRIGHT HOLDER OR
CONTRIBUTOR WILL BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR
CONSEQUENTIAL DAMAGES ARISING IN ANY WAY OUT OF THE USE OF THE PACKAGE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


=head1 SEE ALSO

Geo::Coder::Canada
Geo::Parse::OSM
Text::NLP
=cut

1; # End of Geo::Parser::Text

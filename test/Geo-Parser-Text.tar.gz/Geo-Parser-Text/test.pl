#!/usr/bin/perl
use strict;

use Geo::Parser::Text;

    
my $g = Geo::Parser::Text->new('http://geocode.xyz');
    
$g->scantext('The most important museums of Amsterdam are located on the Museumplein, located at the southwestern side of the Rijksmuseum.');
if ($g->geocode) {
	my $ref = $g->geocode;
	my @matches = @{$ref->{match}};
	my $number_of_matches = 0;
	foreach (@matches) {
		my $match = $_;
		$number_of_matches++;
		print "Match: $number_of_matches\n";
		foreach (keys %$match) {
			print "\t" . $_ . " -> " . $match->{$_} . "\n";
		}
	}
}

